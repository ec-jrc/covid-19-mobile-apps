List of files:

- Attribute description: COVID-19_mobile_apps-attributes.pdf
- Mobile apps to fight the COVID-19 crisis (CSV): COVID-19_mobile_apps.csv